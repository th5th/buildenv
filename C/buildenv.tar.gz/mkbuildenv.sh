#!/bin/bash
git init
git add .
git commit -a -m "Repository initialised by buildenv."
